<!DOCTYPE html>
<!--[if lt IE 7]><html class="ie6 ie"><![endif]--><!--[if IE 7]><html class="ie7 ie"><![endif]--><!--[if IE 8]><html class="ie8 ie"><![endif]--><!--[if IE 9]><html class="ie9 ie"><![endif]-->
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
<title># html color code</title>
<link href="https://www.computerhope.com/cdn/site.css" type="text/css" rel="stylesheet" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta content="Information on the # html color code with its RGB and HSL make up, lighter and darker colors, analogous colors, and trinary colors." name="description" />
<meta itemprop="name" content="# html color code" />
<meta itemprop="description" content="Information on the # html color code with its RGB and HSL make up, lighter and darker colors, analogous colors, and trinary colors." />
<meta property="og:description" content="Information on the # html color code with its RGB and HSL make up, lighter and darker colors, analogous colors, and trinary colors." />
<meta property="og:title" content="# html color code" />
<meta property="og:type" content="article" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="# html color code" />
<meta name="twitter:description" content="Information on the # html color code with its RGB and HSL make up, lighter and darker colors, analogous colors, and trinary colors." />
<meta name="twitter:creator" content="@computerhope" />
<!--[if lt IE 9]><script src="https://www.computerhope.com/cdn/html5shiv.js"></script><![endif]-->
<meta property="og:image" content="https://www.computerhope.com/cdn/color-code.jpg" />
<meta itemprop="image" content="https://www.computerhope.com/cdn/color-code.jpg" />
<link rel="image_src" href="https://www.computerhope.com/cdn/color-code.jpg" />
<link rel="alternate" type="application/rss+xml" title="RSS-Feed" href="https://feeds.feedburner.com/LatestNewPagesOnComputerHope" />
<link rel="apple-touch-icon" href="https://www.computerhope.com/cdn/apple-touch-icon.png" />
<link rel="shortcut icon" href="https://www.computerhope.com/cdn/favicon.ico" type="image/x-icon" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-126444-1', 'auto');
  ga('send', 'pageview');
</script>
</head>
<style type="text/css">.colorpalette {clear: left;margin: 0 0 15px;padding: 0;}.whitebox{ color: black; font-weight: bold; background-color: white; padding: 3px; }.colorpalette div {float: left;height: 95px;list-style: none outside none;margin: 1px 10px 2em 1px;padding: 0;width: 95px;border:1px solid black;}.colorpalette2 {margin: 0 50px 15px;padding: 0;width: 160px;}.colorpalette2 div {height: 50px;list-style: none outside none;margin: 10px 0 0 1px;padding: 0;width: 90px;border:1px solid black;}.swatch{display:block;}.colorpalette3 { margin: 10px 0 15px; padding: 0; } .colorpalette3 div { float: left; height: 90px; list-style: none outside none; margin: 5px 5px 0 1px; padding: 0; width: 88px; border: 1px solid black; }</style><meta name="robots" content="noindex" />
<body>
<div class="skip"><a href="#main-content">Skip to Main Content</a></div>
<div class="wrapper">
<header class="cf"><a href="/"><img src="/cdn/computer-hope.jpg" width="412" height="82" alt="Computer Hope" class="logo"></a><div itemscope itemtype="https://schema.org/SiteNavigationElement"><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post"><input class="sbar" name="q" title="Search" type="text" accesskey="s" /><button type="Submit">Search</button></form><ul id="nav"><li><a href="/oh.htm" title="Questions and answers, troubleshooting, and help">Help</a></li><li><a href="/tips/" title="Computer tips and tricks">Tips</a></li><li><a href="/jargon.htm" title="Computer terms, jargon, and glossary">Dictionary</a></li><li><a href="/history/" title="Computer timeline, events, and biographies">History</a></li><li><a href="/forum/" title="Computer Hope forums and community">Forums</a></li><li><a href="/contact/" title="Contact Computer Hope or other computer companies">Contact</a></li></ul></div></header>
<div class="container ad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="7994873325" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
<div class="container"><ol class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList"><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a href="https://www.computerhope.com/" itemprop="item"><span itemprop="name">Home</span></a><meta itemprop="position" content="1" /></li><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a href="../learnhtm.htm" itemprop="item"><span itemprop="name">HTML help</span></a><meta itemprop="position" content="2" /></li><li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a href="../htmcolor.htm" itemprop="item"><span itemprop="name">HTML color codes</span></a><meta itemprop="position" content="3" /></li></ol></div><div class="container content" id="main-content"> <article>
<h1 class="noupdate">HTML Color Code Tool</h1><p class="tab"><span class="warn">Note:</span> Your HTML color code is not long enough, it should be at least six characters long or equal to three characters if using shorthand.</p><p class="intro">Enter a three or six character HTML color code or click a color swatches to start browsing colors.</p><form action="https://www.computerhope.com/cgi-bin/search.cgi"><p class="ce"><input type="text" title="Search" name="q" size="25" class="bsbar" value="#"><input name="sa" type="submit" value="Search" class="bbtn"></p></form>
<div class="colorpalette3">
<div title="#FF0000" style="background-color: #FF0000; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FF0000'"><span style="color: black; font-weight: bold; background-color: white">#FF0000</span></div>
<div title="#000000" style="background-color: #000000; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=000000'"><span style="color: black; font-weight: bold; background-color: white">#000000</span></div>
<div title="#0000FF" style="background-color: #0000FF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=0000FF'"><span style="color: black; font-weight: bold; background-color: white">#0000FF</span></div>
<div title="#C0C0C0" style="background-color: #C0C0C0; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=C0C0C0'"><span style="color: black; font-weight: bold; background-color: white">#C0C0C0</span></div>
<div title="#FFFFFF" style="background-color: #FFFFFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FFFFFF'"><span style="color: black; font-weight: bold; background-color: white">#FFFFFF</span></div>
<div title="#FFFF00" style="background-color: #FFFF00; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FFFF00'"><span style="color: black; font-weight: bold; background-color: white">#FFFF00</span></div>
<div title="#00FFFF" style="background-color: #00FFFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=00FFFF'"><span style="color: black; font-weight: bold; background-color: white">#00FFFF</span></div>
<div title="#FFA500" style="background-color: #FFA500; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FFA500'"><span style="color: black; font-weight: bold; background-color: white">#FFA500</span></div>
<div title="#00FF00" style="background-color: #00FF00; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=00FF00'"><span style="color: black; font-weight: bold; background-color: white">#00FF00</span></div>
<div title="#808080" style="background-color: #808080; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=808080'"><span style="color: black; font-weight: bold; background-color: white">#808080</span></div>
<div title="#FF00FF" style="background-color: #FF00FF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FF00FF'"><span style="color: black; font-weight: bold; background-color: white">#FF00FF</span></div>
<div title="#800080" style="background-color: #800080; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=800080'"><span style="color: black; font-weight: bold; background-color: white">#800080</span></div>
<div title="#FDD017" style="background-color: #FDD017; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FDD017'"><span style="color: black; font-weight: bold; background-color: white">#FDD017</span></div>
<div title="#0000A0" style="background-color: #0000A0; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=0000A0'"><span style="color: black; font-weight: bold; background-color: white">#0000A0</span></div>
<div title="#3BB9FF" style="background-color: #3BB9FF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=3BB9FF'"><span style="color: black; font-weight: bold; background-color: white">#3BB9FF</span></div>
<div title="#008000" style="background-color: #008000; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=008000'"><span style="color: black; font-weight: bold; background-color: white">#008000</span></div>
<div title="#800000" style="background-color: #800000; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=800000'"><span style="color: black; font-weight: bold; background-color: white">#800000</span></div>
<div title="#ADD8E6" style="background-color: #ADD8E6; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=ADD8E6'"><span style="color: black; font-weight: bold; background-color: white">#ADD8E6</span></div>
<div title="#F778A1" style="background-color: #F778A1; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=F778A1'"><span style="color: black; font-weight: bold; background-color: white">#F778A1</span></div>
<div title="#800517" style="background-color: #800517; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=800517'"><span style="color: black; font-weight: bold; background-color: white">#800517</span></div>
<div title="#736F6E" style="background-color: #736F6E; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=736F6E'"><span style="color: black; font-weight: bold; background-color: white">#736F6E</span></div>
<div title="#F52887" style="background-color: #F52887; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=F52887'"><span style="color: black; font-weight: bold; background-color: white">#F52887</span></div>
<div title="#C11B17" style="background-color: #C11B17; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=C11B17'"><span style="color: black; font-weight: bold; background-color: white">#C11B17</span></div>
<div title="#5CB3FF" style="background-color: #5CB3FF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=5CB3FF'"><span style="color: black; font-weight: bold; background-color: white">#5CB3FF</span></div>
<div title="#A52A2A" style="background-color: #A52A2A; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=A52A2A'"><span style="color: black; font-weight: bold; background-color: white">#A52A2A</span></div>
<div title="#FF8040" style="background-color: #FF8040; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FF8040'"><span style="color: black; font-weight: bold; background-color: white">#FF8040</span></div>
<div title="#2B60DE" style="background-color: #2B60DE; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=2B60DE'"><span style="color: black; font-weight: bold; background-color: white">#2B60DE</span></div>
<div title="#736AFF" style="background-color: #736AFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=736AFF'"><span style="color: black; font-weight: bold; background-color: white">#736AFF</span></div>
<div title="#1589FF" style="background-color: #1589FF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=1589FF'"><span style="color: black; font-weight: bold; background-color: white">#1589FF</span></div>
<div title="#98AFC7" style="background-color: #98AFC7; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=98AFC7'"><span style="color: black; font-weight: bold; background-color: white">#98AFC7</span></div>
<div title="#8D38C9" style="background-color: #8D38C9; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=8D38C9'"><span style="color: black; font-weight: bold; background-color: white">#8D38C9</span></div>
<div title="#307D7E" style="background-color: #307D7E; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=307D7E'"><span style="color: black; font-weight: bold; background-color: white">#307D7E</span></div>
<div title="#F6358A" style="background-color: #F6358A; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=F6358A'"><span style="color: black; font-weight: bold; background-color: white">#F6358A</span></div>
<div title="#151B54" style="background-color: #151B54; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=151B54'"><span style="color: black; font-weight: bold; background-color: white">#151B54</span></div>
<div title="#6D7B8D" style="background-color: #6D7B8D; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=6D7B8D'"><span style="color: black; font-weight: bold; background-color: white">#6D7B8D</span></div>
<div title="#FDEEF4" style="background-color: #FDEEF4; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FDEEF4'"><span style="color: black; font-weight: bold; background-color: white">#FDEEF4</span></div>
<div title="#FF0080" style="background-color: #FF0080; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FF0080'"><span style="color: black; font-weight: bold; background-color: white">#FF0080</span></div>
<div title="#F88017" style="background-color: #F88017; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=F88017'"><span style="color: black; font-weight: bold; background-color: white">#F88017</span></div>
<div title="#2554C7" style="background-color: #2554C7; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=2554C7'"><span style="color: black; font-weight: bold; background-color: white">#2554C7</span></div>
<div title="#FFF8C6" style="background-color: #FFF8C6; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FFF8C6'"><span style="color: black; font-weight: bold; background-color: white">#FFF8C6</span></div>
<div title="#D4A017" style="background-color: #D4A017; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=D4A017'"><span style="color: black; font-weight: bold; background-color: white">#D4A017</span></div>
<div title="#306EFF" style="background-color: #306EFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=306EFF'"><span style="color: black; font-weight: bold; background-color: white">#306EFF</span></div>
<div title="#151B8D" style="background-color: #151B8D; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=151B8D'"><span style="color: black; font-weight: bold; background-color: white">#151B8D</span></div>
<div title="#9E7BFF" style="background-color: #9E7BFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=9E7BFF'"><span style="color: black; font-weight: bold; background-color: white">#9E7BFF</span></div>
<div title="#EAC117" style="background-color: #EAC117; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=EAC117'"><span style="color: black; font-weight: bold; background-color: white">#EAC117</span></div>
<div title="#E0FFFF" style="background-color: #E0FFFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=E0FFFF'"><span style="color: black; font-weight: bold; background-color: white">#E0FFFF</span></div>
<div title="#15317E" style="background-color: #15317E; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=15317E'"><span style="color: black; font-weight: bold; background-color: white">#15317E</span></div>
<div title="#6C2DC7" style="background-color: #6C2DC7; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=6C2DC7'"><span style="color: black; font-weight: bold; background-color: white">#6C2DC7</span></div>
<div title="#FBB917" style="background-color: #FBB917; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FBB917'"><span style="color: black; font-weight: bold; background-color: white">#FBB917</span></div>
<div title="#FCDFFF" style="background-color: #FCDFFF; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FCDFFF'"><span style="color: black; font-weight: bold; background-color: white">#FCDFFF</span></div>
<div title="#15317E" style="background-color: #15317E; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=15317E'"><span style="color: black; font-weight: bold; background-color: white">#15317E</span></div>
<div title="#254117" style="background-color: #254117; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=254117'"><span style="color: black; font-weight: bold; background-color: white">#254117</span></div>
<div title="#FAAFBE" style="background-color: #FAAFBE; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=FAAFBE'"><span style="color: black; font-weight: bold; background-color: white">#FAAFBE</span></div>
<div title="#357EC7" style="background-color: #357EC7; cursor: pointer;" onclick="location.href='https://www.computerhope.com/cgi-bin/htmlcolor.pl?c=357EC7'"><span style="color: black; font-weight: bold; background-color: white">#357EC7</span></div>
</div>
<p style="clear: both;">&nbsp;</p><p class="ce"><a href="https://www.computerhope.com/htmcolor.htm">Back to HTML color codes page</a></p>
</article>
<div class="bottomad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="6514780129" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
<div class="related">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="9849691723" data-ad-format="autorelaxed"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
</div>
<div id="meta_wrap" class="cf"><ul class="options cf"><li class="useful-page"><span class="nolink">Was this page useful?</span><a href="/cgi-bin/feedback.cgi?yes" rel="nofollow" class="first-child">Yes</a><a href="/cgi-bin/feedback.cgi?no" rel="nofollow">No</a></li><li><ul><li class="feedback"><a href="/feedback/" rel="nofollow" title="Give us your feedback about this page">Feedback</a></li><li class="email"><a href="/contact/" rel="nofollow" title="E-mail Computer Hope">E-mail</a></li><li class="share"><a href="/share/" rel="nofollow" title="Share this page with friends and social networks">Share</a></li><li class="first-child print"><a href="#" onclick="window.print();return false;" rel="nofollow" title="Print a copy of this page">Print</a></li></ul></li></ul></div>
</div>
<footer><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post" class="cf"><input class="sbar" name="q" title="Search" type="text" /><button type="Submit">Search</button></form><ul class="cf"><li class="recent-pages"><ol><li class="widget-title"><h5>Recently added pages</h5></li><li id="ra1"></li><li id="ra2"></li><li id="ra3"></li><li id="ra4"></li><li id="ra5"></li><li><a href="/whatnew.htm">View all recent updates</a></li></ol></li><li class="useful-links"><ol><li class="widget-title"><h5>Useful links</h5></li><li><a href="/more.htm">About Computer Hope</a></li><li><a href="/sindex.htm">Site Map</a></li><li><a href="/forum/">Forum</a></li><li><a href="/contact/">Contact Us</a></li><li><a href="/issues/ch000586.htm">How to Help</a></li><li><a href="/chtop10.htm">Top 10 pages</a></li></ol></li><li class="social-networks"><ol><li class="widget-title first-child"><h5>Follow us</h5></li><li><a href="https://www.facebook.com/computerhope/" class="facebook">Facebook</a></li><li><a href="https://twitter.com/computerhope/" class="twitter">Twitter</a></li><li><a href="https://www.pinterest.com/computerhope/" class="pinterest">Pinterest</a></li><li><a href="https://www.youtube.com/user/Computerhope/" class="youtube">YouTube</a></li><li><a href="/rss.htm" class="rss">RSS</a></li></ol></li></ul><div class="copyright">&copy; 2020 Computer Hope<br><a href="/legal.htm" class="legal">Legal Disclaimer - Privacy Statement</a></div></footer>
</div>
<script async src="https://www.computerhope.com/recent.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://www.computerhope.com/cdn/site.js"></script>
<script async src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=computerhope"></script>
</body>
</html>