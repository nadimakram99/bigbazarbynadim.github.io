<!DOCTYPE html>
<!--[if lt IE 7]><html class="ie6 ie"><![endif]--><!--[if IE 7]><html class="ie7 ie"><![endif]--><!--[if IE 8]><html class="ie8 ie"><![endif]--><!--[if IE 9]><html class="ie9 ie"><![endif]-->
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
<title>Computer Hope Quiz 1</title>
<link href="https://www.computerhope.com/cdn/site.css" type="text/css" rel="stylesheet" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta content="What does the term MIME stand for?" name="description" />
<meta itemprop="name" content="Computer Hope Quiz 1" />
<meta itemprop="description" content="What does the term MIME stand for?" />
<meta property="og:description" content="What does the term MIME stand for?" />
<meta property="og:title" content="Computer Hope Quiz 1" />
<meta property="og:type" content="article" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Computer Hope Quiz 1" />
<meta name="twitter:description" content="What does the term MIME stand for?" />
<meta name="twitter:creator" content="@computerhope" />
<!--[if lt IE 9]><script src="https://www.computerhope.com/cdn/html5shiv.js"></script><![endif]-->
<meta property="og:image" content="https://www.computerhope.com/cdn/dictionary.jpg" />
<meta itemprop="image" content="https://www.computerhope.com/cdn/dictionary.jpg" />
<link rel="image_src" href="https://www.computerhope.com/cdn/dictionary.jpg" />
<link rel="alternate" type="application/rss+xml" title="RSS-Feed" href="https://feeds.feedburner.com/LatestNewPagesOnComputerHope" />
<link rel="apple-touch-icon" href="https://www.computerhope.com/cdn/apple-touch-icon.png" />
<link rel="shortcut icon" href="https://www.computerhope.com/cdn/favicon.ico" type="image/x-icon" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-126444-1', 'auto');
  ga('send', 'pageview');
</script>
</head>
<body>
<div class="skip"><a href="#main-content">Skip to Main Content</a></div>
<div class="wrapper">
<header class="cf"><a href="/"><img src="/cdn/computer-hope.jpg" width="412" height="82" alt="Computer Hope" class="logo"></a><div itemscope itemtype="https://schema.org/SiteNavigationElement"><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post"><input class="sbar" name="q" title="Search" type="text" accesskey="s" /><button type="Submit">Search</button></form><ul id="nav"><li><a href="/oh.htm" title="Questions and answers, troubleshooting, and help">Help</a></li><li><a href="/tips/" title="Computer tips and tricks">Tips</a></li><li><a href="/jargon.htm" title="Computer terms, jargon, and glossary">Dictionary</a></li><li><a href="/history/" title="Computer timeline, events, and biographies">History</a></li><li><a href="/forum/" title="Computer Hope forums and community">Forums</a></li><li><a href="/contact/" title="Contact Computer Hope or other computer companies">Contact</a></li></ul></div></header>
<div class="container ad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="7994873325" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
<div class="container content" id="main-content">
<article>
<p>Welcome to the Computer Hope quiz, a fun and interactive series of questions relating to computer hardware, software, terminology, Linux, networking, programming, and much more. In addition to being a test, this quiz also helps teach you more about computers by explaining each answer as you progress through the test. This test also has no time limit and any page can be easily bookmarked and continued at a later time. For those who complete the test your name and test, results can be posted into the <a href="https://www.computerhope.com/cgi-bin/quiz.pl?allresults">quiz results leaderboard</a>.</p><h1 class="noupdate">Computer Hope Quiz #1 of 152</h1><p><span class="nb">Definition</span>: <b>What does the term MIME stand for?</b><br><span class="rg">Difficulty: medium</span></p>
<p>1. <a href="https://www.computerhope.com/cgi-bin/quiz.pl?crypt=53616c7465645f5fc0a8ac7e64b299ac340b13ecabef4abc44e4f6d5dcc4c4f2cabc78ff27ea6b4fbac09e1491b29dfd1bba19da0a589e505e738d66b1c4f691ddba0d6ad2e0752a6e5c6ff5270920c9" rel="nofollow">Mail Internet Mail Exchange</a><br>
2. <a href="https://www.computerhope.com/cgi-bin/quiz.pl?crypt=53616c7465645f5fd6f204b1bcf27d3b5bf8f5afa0a277be75e4b595972bf524dc684724b883306ec830cb40a98b1179f6518364b20801d5bcf985ec3b0700c2cfe0ba5cc04cdd4b86e37ff15e35d3bf" rel="nofollow"> Mail Interleave Method Exchange</a><br>
3. <a href="https://www.computerhope.com/cgi-bin/quiz.pl?crypt=53616c7465645f5fff5e491763a291c7a18200ce761165875354a0f4ce01e7d3a5213964d937fcbf15aa3e7b04fa29a8e10a0458d3dbd1191ec363d3caf7b026b2f47766a4497002f90fb3a2073f308a" rel="nofollow"> Multipurpose Internet Mail Extensions</a><br>
4. <a href="https://www.computerhope.com/cgi-bin/quiz.pl?crypt=53616c7465645f5f3fec39b69932860cba3572281086c1a944e41a1013e4229c700a3ec1be1d06eb6d616e004d1cff85ab1eb84200610c3faab7d45bc8f09186cddbbbe165c5691ceb3cc803ab9d52cd" rel="nofollow"> Multipurpose Interleave Mail Exchange</a><br>
</p><br><p class="ce" id="noprint"><a href="https://www.computerhope.com/">Back to Computer Hope</a></p> </article>
<div class="bottomad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="6514780129" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
<div class="related">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="9849691723" data-ad-format="autorelaxed"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
</div>
<div id="meta_wrap" class="cf"><ul class="options cf"><li class="useful-page"><span class="nolink">Was this page useful?</span><a href="/cgi-bin/feedback.cgi?yes" rel="nofollow" class="first-child">Yes</a><a href="/cgi-bin/feedback.cgi?no" rel="nofollow">No</a></li><li><ul><li class="feedback"><a href="/feedback/" rel="nofollow" title="Give us your feedback about this page">Feedback</a></li><li class="email"><a href="/contact/" rel="nofollow" title="E-mail Computer Hope">E-mail</a></li><li class="share"><a href="/share/" rel="nofollow" title="Share this page with friends and social networks">Share</a></li><li class="first-child print"><a href="#" onclick="window.print();return false;" rel="nofollow" title="Print a copy of this page">Print</a></li></ul></li></ul></div>
</div>
<footer><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post" class="cf"><input class="sbar" name="q" title="Search" type="text" /><button type="Submit">Search</button></form><ul class="cf"><li class="recent-pages"><ol><li class="widget-title"><h5>Recently added pages</h5></li><li id="ra1"></li><li id="ra2"></li><li id="ra3"></li><li id="ra4"></li><li id="ra5"></li><li><a href="/whatnew.htm">View all recent updates</a></li></ol></li><li class="useful-links"><ol><li class="widget-title"><h5>Useful links</h5></li><li><a href="/more.htm">About Computer Hope</a></li><li><a href="/sindex.htm">Site Map</a></li><li><a href="/forum/">Forum</a></li><li><a href="/contact/">Contact Us</a></li><li><a href="/issues/ch000586.htm">How to Help</a></li><li><a href="/chtop10.htm">Top 10 pages</a></li></ol></li><li class="social-networks"><ol><li class="widget-title first-child"><h5>Follow us</h5></li><li><a href="https://www.facebook.com/computerhope/" class="facebook">Facebook</a></li><li><a href="https://twitter.com/computerhope/" class="twitter">Twitter</a></li><li><a href="https://www.pinterest.com/computerhope/" class="pinterest">Pinterest</a></li><li><a href="https://www.youtube.com/user/Computerhope/" class="youtube">YouTube</a></li><li><a href="/rss.htm" class="rss">RSS</a></li></ol></li></ul><div class="copyright">&copy; 2020 Computer Hope<br><a href="/legal.htm" class="legal">Legal Disclaimer - Privacy Statement</a></div></footer>
</div>
<script async src="https://www.computerhope.com/recent.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://www.computerhope.com/cdn/site.js"></script>
</body>
</html>