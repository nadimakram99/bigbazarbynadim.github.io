<!DOCTYPE html>
<!--[if lt IE 7]><html class="ie6 ie"><![endif]--><!--[if IE 7]><html class="ie7 ie"><![endif]--><!--[if IE 8]><html class="ie8 ie"><![endif]--><!--[if IE 9]><html class="ie9 ie"><![endif]-->
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
<title>February 19 computer history</title>
<link href="https://www.computerhope.com/cdn/site.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://computerhope.cachefly.net/jquery.datepick.css" /><style type="text/css" media="all">
 #column1-wrap{ float: left; width: 100%; }
 #column1{ margin-right: 200px; }
 #column2{ padding-top: 1.5em; float: left; width: 220px; margin-left: -220px; }
 #column2 p {
	 padding: 0!important;
}

 
 .cssTitle0 { font-size: 16px; color: #FFFFFF; background-color: #2a70d0; padding: 4px;}
 .cssHeading0 { font-size: 14px; color: #FFFFFF; background-color: #2a70d0; padding: 4px;}
 .cssDays0 { font-size: 16px; color: #000000; background-color: #FFFFFF; padding: 4px;}
 .cssWeeks0 { font-size: 14px; color: #FFFFFF; background-color: #2a70d0; padding: 4px;}
 .cssSaturdays0 { font-size: 16px; color: #0000D0; background-color: #F6F6FF; padding: 4px;}
 .cssSundays0 { font-size: 16px; color: #D00000; background-color: #FFF0F0; padding: 4px;}
 .cssHilight0 { font-size: 16px; color: #000000; background-color: #FFFF00; cursor: pointer; padding: 4px;}
 
 .historyb {
	background: #2c87f0;
	padding-left: 9px;
	padding-right: 9px;
	padding-top: 3px;
	padding-bottom: 3px;
	color: #fff;
	border: 0;
	margin: 12px 0 35px 0;
 }
.historyc {
	width: 80px;
 }
 
 
 @media only screen and (max-width:764px) {
 #column2 {
 	display: none;
 }
 #column1 {
 	padding-top: 0!important;
 	margin-right: 0!important;
 }
 }
 </style><script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta content="Important past computer history events that happened on February 19 that changed computers forever." name="description" />
<meta itemprop="name" content="February 19 computer history" />
<meta itemprop="description" content="Important past computer history events that happened on February 19 that changed computers forever." />
<meta property="og:description" content="Important past computer history events that happened on February 19 that changed computers forever." />
<meta property="og:title" content="February 19 computer history" />
<meta property="og:type" content="article" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="February 19 computer history" />
<meta name="twitter:description" content="Important past computer history events that happened on February 19 that changed computers forever." />
<meta name="twitter:creator" content="@computerhope" />
<!--[if lt IE 9]><script src="https://www.computerhope.com/cdn/html5shiv.js"></script><![endif]-->
<meta property="og:image" content="https://www.computerhope.com/cdn/dictionary.jpg" />
<meta itemprop="image" content="https://www.computerhope.com/cdn/dictionary.jpg" />
<link rel="image_src" href="https://www.computerhope.com/cdn/dictionary.jpg" />
<link rel="alternate" type="application/rss+xml" title="RSS-Feed" href="https://feeds.feedburner.com/LatestNewPagesOnComputerHope" />
<link rel="apple-touch-icon" href="https://www.computerhope.com/cdn/apple-touch-icon.png" />
<link rel="shortcut icon" href="https://www.computerhope.com/cdn/favicon.ico" type="image/x-icon" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-126444-1', 'auto');
  ga('send', 'pageview');
</script>
</head>
<body>
<div class="skip"><a href="#main-content">Skip to Main Content</a></div>
<div class="wrapper">
<header class="cf"><a href="/"><img src="/cdn/computer-hope.jpg" width="412" height="82" alt="Computer Hope" class="logo"></a><div itemscope itemtype="https://schema.org/SiteNavigationElement"><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post"><input class="sbar" name="q" title="Search" type="text" accesskey="s" /><button type="Submit">Search</button></form><ul id="nav"><li><a href="/oh.htm" title="Questions and answers, troubleshooting, and help">Help</a></li><li><a href="/tips/" title="Computer tips and tricks">Tips</a></li><li><a href="/jargon.htm" title="Computer terms, jargon, and glossary">Dictionary</a></li><li><a href="/history/" title="Computer timeline, events, and biographies">History</a></li><li><a href="/forum/" title="Computer Hope forums and community">Forums</a></li><li><a href="/contact/" title="Contact Computer Hope or other computer companies">Contact</a></li></ul></div></header>
<div class="container ad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="7994873325" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
<div class="container content" id="main-content">
<article>
<div id="column1-wrap">
<div id="column1">
<br><h1 class="noupdate">This day in computer history</h1><div style="margin-top: -20px; margin-right: 75px;"><b>February 19</b> - The 50th day of 2020. It's a leap year and there are 316 days left in the year.</div><br><img alt="Apple" class="floatLeft" src="https://www.computerhope.com/history/apple.jpg"><span class="bb">February 19, 1987</span><br><i>33 years ago</i><br><p class="tab">The domain apple.com goes onlines.</p><br><img alt="Computer" class="floatLeft" src="https://www.computerhope.com/history/misc.jpg"><span class="bb">February 19, 2008</span><br><i>12 years ago</i><br><p class="tab">The HD player war comes to an end when HD DVD calls it quit, making Blu-ray the victor.</p><br><br><b>Related pages:</b> <a href="https://www.computerhope.com/jargon/comp/apple.htm
">Apple</a>, <a href="https://www.computerhope.com/jargon/b/bd.htm
">Blu-ray</a>, <a href="https://www.computerhope.com/jargon/d/domain.htm
">Domain</a>, <a href="https://www.computerhope.com/jargon/d/dvd.htm
">DVD</a>, <a href="https://www.computerhope.com/jargon/h/hddvd.htm
">HD DVD</a>, <a href="https://www.computerhope.com/jargon/o/online.htm
">Online</a><br></div></div><div id="column2"><br><br><div id="inlineDatepicker"></div><form action="https://www.computerhope.com/cgi-bin/history.pl" method="get">
<p style="margin:0!important"><b>Date:</b> <input type="text" name="date" id="popupDatepicker" class="historyc" />
<input type="submit" value="Open" class="historyb" /></p>
</form><p class="ce" style="margin:0!important"><a href="https://www.computerhope.com/history/198090.htm">Other events in 1987</a><br><a href="https://www.computerhope.com/history/2000.htm">Other events in 2008</a><br></p>
</div><p style="clear: both;">&nbsp;</p><br><p class="ce"><a href="https://www.computerhope.com/">Home</a> - <a href="https://www.computerhope.com/cgi-bin/wotd.cgi">Today's computer word</a> - <a href="https://www.computerhope.com/history">Computer History</a><br><br><a href="https://feedburner.google.com/fb/a/mailverify?uri=TodayInComputerHistory" onclick="window.open('https://feedburner.google.com/fb/a/mailverify?uri=TodayInComputerHistory', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true" target="popupwindow">Get daily news events delivered to your e-mail</a></p><br><br> </article>
<div class="bottomad">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="6514780129" data-ad-format="auto"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
<div class="related">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-3999293766533555" data-ad-slot="9849691723" data-ad-format="autorelaxed"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
</div>
<div id="meta_wrap" class="cf"><ul class="options cf"><li class="useful-page"><span class="nolink">Was this page useful?</span><a href="/cgi-bin/feedback.cgi?yes" rel="nofollow" class="first-child">Yes</a><a href="/cgi-bin/feedback.cgi?no" rel="nofollow">No</a></li><li><ul><li class="feedback"><a href="/feedback/" rel="nofollow" title="Give us your feedback about this page">Feedback</a></li><li class="email"><a href="/contact/" rel="nofollow" title="E-mail Computer Hope">E-mail</a></li><li class="share"><a href="/share/" rel="nofollow" title="Share this page with friends and social networks">Share</a></li><li class="first-child print"><a href="#" onclick="window.print();return false;" rel="nofollow" title="Print a copy of this page">Print</a></li></ul></li></ul></div>
</div>
<footer><form action="https://www.computerhope.com/cgi-bin/search.cgi" method="post" class="cf"><input class="sbar" name="q" title="Search" type="text" /><button type="Submit">Search</button></form><ul class="cf"><li class="recent-pages"><ol><li class="widget-title"><h5>Recently added pages</h5></li><li id="ra1"></li><li id="ra2"></li><li id="ra3"></li><li id="ra4"></li><li id="ra5"></li><li><a href="/whatnew.htm">View all recent updates</a></li></ol></li><li class="useful-links"><ol><li class="widget-title"><h5>Useful links</h5></li><li><a href="/more.htm">About Computer Hope</a></li><li><a href="/sindex.htm">Site Map</a></li><li><a href="/forum/">Forum</a></li><li><a href="/contact/">Contact Us</a></li><li><a href="/issues/ch000586.htm">How to Help</a></li><li><a href="/chtop10.htm">Top 10 pages</a></li></ol></li><li class="social-networks"><ol><li class="widget-title first-child"><h5>Follow us</h5></li><li><a href="https://www.facebook.com/computerhope/" class="facebook">Facebook</a></li><li><a href="https://twitter.com/computerhope/" class="twitter">Twitter</a></li><li><a href="https://www.pinterest.com/computerhope/" class="pinterest">Pinterest</a></li><li><a href="https://www.youtube.com/user/Computerhope/" class="youtube">YouTube</a></li><li><a href="/rss.htm" class="rss">RSS</a></li></ol></li></ul><div class="copyright">&copy; 2020 Computer Hope<br><a href="/legal.htm" class="legal">Legal Disclaimer - Privacy Statement</a></div></footer>
</div>
<script async src="https://www.computerhope.com/recent.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="https://computerhope.cachefly.net/jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	$('#popupDatepicker').datepick({onSelect: showDate});
	$('#inlineDatepicker').datepick({onSelect: showDate});
});

function showDate(date) {
	
	var d = new Date(date);
	var curr_date = d.getDate(date);
	var curr_month = d.getMonth(date);
	curr_month += 1;
	var curr_year = d.getFullYear(date);
	
	var elem = document.getElementById("popupDatepicker");
	elem.value = curr_month + '-' + curr_date
}
</script>
<script src="https://www.computerhope.com/cdn/site.js"></script>
<script async src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=computerhope"></script>
</body>
</html>