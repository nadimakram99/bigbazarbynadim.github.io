<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="https://www.computerhope.com/forum/Themes/default/css/index.css?fin20" />
<script type="text/javascript" src="https://www.computerhope.com/forum/Themes/default/scripts/script.js?fin20"></script>
<script type="text/javascript" src="https://www.computerhope.com/forum/Themes/default/scripts/theme.js?fin20"></script>
<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://www.computerhope.com/forum/Themes/default";
		var smf_default_theme_url = "https://www.computerhope.com/forum/Themes/default";
		var smf_images_url = "https://www.computerhope.com/forum/Themes/default/images";
		var smf_scripturl = "https://www.computerhope.com/forum/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "ISO-8859-1";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta name="description" content="Computer Hope - Index" />
<meta name="keywords" content="Free Computer Help and technical support forum and board" />
<title>Computer Hope - Index</title>
<link rel="canonical" href="https://www.computerhope.com/forum/index.php" />
<link rel="help" href="https://www.computerhope.com/forum/index.php?action=help" />
<link rel="search" href="https://www.computerhope.com/forum/index.php?action=search" />
<link rel="contents" href="https://www.computerhope.com/forum/index.php" />
<link rel="alternate" type="application/rss+xml" title="Computer Hope - RSS" href="https://www.computerhope.com/forum/index.php?type=rss;action=.xml" />
<script type="text/javascript"><!-- // --><![CDATA[
		var smf_avatarMaxWidth = 65;
		var smf_avatarMaxHeight = 65;
	window.addEventListener("load", smf_avatarResize, false);
	// ]]></script><script language="JavaScript" type="text/javascript" src="https://www.computerhope.com/cdn/overlib/overlib.js"></script></head><body><div id="infobar"><a href="https://www.computerhope.com/forum/index.php?action=register"><p>Welcome <b>guest</b>. Before posting on our computer help forum, you must register. Click here it's easy and free.</p></a></div>
<div id="wrapper" style="width: 90%">
<div id="header"><div class="frame">
<div id="top_section">
<h1 class="forumtitle">Computer Hope Forum</h1>
<img id="upshrink" src="https://www.computerhope.com/forum/Themes/default/images/upshrink.png" alt="*" title="Shrink or expand the header." style="display: none;" />
<div id="site_menu" class="floatright"><ul class="dropmenu" id="site_nav"><li><a class="firstlevel" href="https://www.computerhope.com/"><span class="firstlevel">Main page</span></a></li><li><a class="firstlevel" href="https://www.computerhope.com/oh.htm"><span class="firstlevel">Free help</span></a></li><li><a class="firstlevel" href="https://www.computerhope.com/tips/"><span class="firstlevel">Tips</span></a></li><li><a class="firstlevel" href="https://www.computerhope.com/jargon.htm"><span class="firstlevel">Dictionary</span></a></li><li><a class="active firstlevel" href="https://www.computerhope.com/forum/"><span class="firstlevel">Forum</span></a></li><li><a class="firstlevel" href="https://www.computerhope.com/network.htm"><span class="firstlevel">Links</span></a></li><li><a class="firstlevel" href="https://www.computerhope.com/cgi-bin/mail.cgi"><span class="firstlevel">Contact</span></a></li></ul></div>
</div>
<div id="upper_section" class="middletext">
<div class="user">
<script type="text/javascript" src="https://www.computerhope.com/forum/Themes/default/scripts/sha1.js"></script>
<form id="guest_form" action="https://www.computerhope.com/forum/index.php?action=login2" method="post" accept-charset="ISO-8859-1" onsubmit="hashLoginPassword(this, 'abce47b1dc4e8e634b69963461bd3365');">
<div class="info">Welcome, <strong>Guest</strong>. Please <a href="https://www.computerhope.com/forum/index.php?action=login">login</a> or <a href="https://www.computerhope.com/forum/index.php?action=register">register</a>.<br />Did you miss your <a href="https://www.computerhope.com/forum/index.php?action=activate">activation email</a>?</div>
<input type="text" name="user" size="10" class="input_text" />
<input type="password" name="passwrd" size="10" class="input_password" />
<select name="cookielength">
<option value="60">1 Hour</option>
<option value="1440">1 Day</option>
<option value="10080">1 Week</option>
<option value="43200">1 Month</option>
<option value="-1" selected="selected">Forever</option>
</select>
<input type="submit" value="Login" class="button_submit" /><br />
<div class="info">Login with username, password and session length</div>
<input type="hidden" name="hash_passwrd" value="" /><input type="hidden" name="a4ba615fb8" value="abce47b1dc4e8e634b69963461bd3365" />
</form>
</div>
<div class="news normaltext">
<form id="search_form" action="https://www.computerhope.com/cgi-bin/search.cgi" method="post" accept-charset="ISO-8859-1">
<input type="text" name="q" value="" class="input_text" />&nbsp;
<input type="submit" name="submit" value="Search" class="button_submit" />
<br /><a href="https://www.computerhope.com/forum/index.php?action=search">Forum only search</a><br /></form>
<h2>News: </h2>
<p></p>
</div>
</div>
<br class="clear" />
<script type="text/javascript"><!-- // --><![CDATA[
			var oMainHeaderToggle = new smc_Toggle({
				bToggleEnabled: true,
				bCurrentlyCollapsed: false,
				aSwappableContainers: [
					'upper_section'
				],
				aSwapImages: [
					{
						sId: 'upshrink',
						srcExpanded: smf_images_url + '/upshrink.png',
						altExpanded: 'Shrink or expand the header.',
						srcCollapsed: smf_images_url + '/upshrink2.png',
						altCollapsed: 'Shrink or expand the header.'
					}
				],
				oThemeOptions: {
					bUseThemeSettings: false,
					sOptionName: 'collapse_header',
					sSessionVar: 'a4ba615fb8',
					sSessionId: 'abce47b1dc4e8e634b69963461bd3365'
				},
				oCookieOptions: {
					bUseCookie: true,
					sCookieName: 'upshrink'
				}
			});
		// ]]></script>
<div id="main_menu">
<ul class="dropmenu" id="menu_nav">
<li id="button_home">
<a class="active firstlevel" href="https://www.computerhope.com/forum/index.php">
<span class="last firstlevel">Home</span>
</a>
</li>
<li id="button_help">
<a class="firstlevel" href="https://www.computerhope.com/forum/index.php?action=help">
<span class="firstlevel">Help</span>
</a>
</li>
<li id="button_login">
<a class="firstlevel" href="https://www.computerhope.com/forum/index.php?action=login">
<span class="firstlevel">Login</span>
</a>
</li>
<li id="button_register">
<a class="firstlevel" href="https://www.computerhope.com/forum/index.php?action=register">
<span class="last firstlevel">Register</span>
</a>
</li>
</ul>
</div>
<br class="clear" />
</div></div>
<div id="content_section"><div class="frame">
<div id="main_content_section">
<div class="navigate_section">
<ul>
<li class="last">
<a href="https://www.computerhope.com/forum/index.php"><span>Computer Hope</span></a>
</li>
</ul>
</div>
<div id="boardindex_table">
<table class="table_list">
<tbody class="header" id="category_4">
<tr>
<td colspan="4">
<div class="cat_bar">
<h3 class="catbg">
<a id="c4"></a>Microsoft
</h3>
</div>
</td>
</tr>
</tbody>
<tbody class="content" id="category_4_boards">
<tr id="board_1" class="windowbg2">
<td class="icon windowbg" rowspan="2">
<a href="https://www.computerhope.com/forum/index.php/board,1.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,1.0.html" name="b1">Microsoft Windows</a>
<p>Microsoft Windows 3.x, 9x, ME, 2000, XP, 2003, Vista , 7, 8, and 10 discussions and help.</p>
</td>
<td class="stats windowbg">
<p>289494 Posts <br />
34571 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=140339">strollin</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,176023.msg998491.html#new" title="Re: win 7 to win 10">Re: win 7 to win 10</a><br />
on <strong>Today</strong> at 07:27:32 AM
</p>
</td>
</tr>
<tr id="board_1_children">
<td colspan="3" class="children windowbg">
<strong>Child Boards</strong>: <a href="https://www.computerhope.com/forum/index.php/board,59.0.html" title="No New Posts (Topics: 1029, Posts: 5758)">Windows 10</a>, <a href="https://www.computerhope.com/forum/index.php/board,57.0.html" title="No New Posts (Topics: 519, Posts: 2864)">Windows 8</a>, <a href="https://www.computerhope.com/forum/index.php/board,49.0.html" title="No New Posts (Topics: 8199, Posts: 80933)">Windows Vista and 7</a>, <a href="https://www.computerhope.com/forum/index.php/board,50.0.html" title="No New Posts (Topics: 22799, Posts: 182873)">Windows XP</a>, <a href="https://www.computerhope.com/forum/index.php/board,47.0.html" title="No New Posts (Topics: 376, Posts: 3142)">Windows Server</a>, <a href="https://www.computerhope.com/forum/index.php/board,51.0.html" title="No New Posts (Topics: 793, Posts: 6062)">Windows NT/2000</a>, <a href="https://www.computerhope.com/forum/index.php/board,48.0.html" title="No New Posts (Topics: 856, Posts: 7862)">Windows 3.x/9x/ME</a>
</td>
</tr>
<tr id="board_2" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,2.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,2.0.html" name="b2">Microsoft DOS</a>
<p>MS-DOS, Windows command prompt, and batch files discussions and help.</p>
</td>
<td class="stats windowbg">
<p>81760 Posts <br />
10443 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=5759">Sidewinder</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175962.msg998385.html#new" title="Re: copy folder with latest time stamp using batch file">Re: copy folder with lat...</a><br />
on February 15, 2020, 07:34:00 AM
</p>
</td>
</tr>
</tbody>
<tbody class="divider">
<tr>
<td colspan="4"></td>
</tr>
</tbody>
<tbody class="header" id="category_3">
<tr>
<td colspan="4">
<div class="cat_bar">
<h3 class="catbg">
<a id="c3"></a>Hardware
</h3>
</div>
</td>
</tr>
</tbody>
<tbody class="content" id="category_3_boards">
<tr id="board_5" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,5.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,5.0.html" name="b5">Hardware</a>
<p>Video cards, HDD, phones, printers, sound, tablets, overclocking, and other hardware help.</p>
</td>
<td class="stats windowbg">
<p>231835 Posts <br />
28321 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=72918">Allan</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,176030.msg998489.html#new" title="MOVED: win 7 to win 10">MOVED: win 7 to win 10</a><br />
on <strong>Today</strong> at 05:28:28 AM
</p>
</td>
</tr>
<tr id="board_4" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,4.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,4.0.html" name="b4">Drivers</a>
<p>Locating, discussions, and help with drivers, firmware, and updates.</p>
</td>
<td class="stats windowbg">
<p>24919 Posts <br />
3085 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=140339">strollin</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175378.msg997482.html#new" title="Re: Help for external drivers, ripping, etc (from a tech beginner)">Re: Help for external dr...</a><br />
on January 28, 2020, 05:21:15 PM
</p>
</td>
</tr>
</tbody>
<tbody class="divider">
<tr>
<td colspan="4"></td>
</tr>
</tbody>
<tbody class="header" id="category_1">
<tr>
<td colspan="4">
<div class="cat_bar">
<h3 class="catbg">
<a id="c1"></a>Software
</h3>
</div>
</td>
</tr>
</tbody>
<tbody class="content" id="category_1_boards">
<tr id="board_7" class="windowbg2">
<td class="icon windowbg" rowspan="2">
<a href="https://www.computerhope.com/forum/index.php/board,7.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,7.0.html" name="b7">Computer viruses and spyware</a>
<p>Computer anti-virus, security, spyware, viruses, worms, and other malware help.</p>
<p class="moderators">Moderators: <a href="https://www.computerhope.com/forum/index.php?action=profile;u=1745" title="Board Moderator">SuperDave</a>, <a href="https://www.computerhope.com/forum/index.php?action=profile;u=37166" title="Board Moderator">evilfantasy</a>, <a href="https://www.computerhope.com/forum/index.php?action=profile;u=89015" title="Board Moderator">Sneakyone</a></p>
</td>
<td class="stats windowbg">
<p>111589 Posts <br />
8905 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191074">hearthot2545</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,176031.msg998492.html#new" title="Topic: Need help for ransomware virus  ">Topic: Need help for ran...</a><br />
on <strong>Today</strong> at 07:35:43 AM
</p>
</td>
</tr>
<tr id="board_7_children">
<td colspan="3" class="children windowbg">
<strong>Child Boards</strong>: <a href="https://www.computerhope.com/forum/index.php/board,53.0.html" title="No New Posts (Topics: 832, Posts: 17827)">Virus and spyware removal</a>
</td>
</tr>
<tr id="board_9" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,9.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,9.0.html" name="b9">Computer software</a>
<p>Discussions and help with other software, programs, and utilities.</p>
</td>
<td class="stats windowbg">
<p>80274 Posts <br />
11451 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=190926">KittySt</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,174127.msg998477.html#new" title="Re: Looking for picture slideshow creator with basic video editing capabilities">Re: Looking for picture ...</a><br />
on February 18, 2020, 07:02:27 PM
</p>
</td>
</tr>
<tr id="board_3" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,3.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,3.0.html" name="b3">Internet browsers</a>
<p>Internet Explorer, Firefox, Opera, Safari, and other browser�s discussions and help.</p>
</td>
<td class="stats windowbg">
<p>36689 Posts <br />
4438 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=3421">patio</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175763.msg997799.html#new" title="Re: Firefox Bookmarks">Re: Firefox Bookmarks</a><br />
on February 01, 2020, 03:16:08 PM
</p>
</td>
</tr>
<tr id="board_11" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,11.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,11.0.html" name="b11">Computer games</a>
<p>Computer gaming discussions, cheats, and help.</p>
</td>
<td class="stats windowbg">
<p>22263 Posts <br />
2494 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191043">azajali43</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175185.msg998464.html#new" title="Re: Best settings for Fortnite ?">Re: Best settings for Fo...</a><br />
on February 18, 2020, 07:14:10 AM
</p>
</td>
</tr>
<tr id="board_6" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,6.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,6.0.html" name="b6">Computer programming</a>
<p>Computer programming and debugging discussions and help.</p>
</td>
<td class="stats windowbg">
<p>17603 Posts <br />
2800 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=135682">12Strings</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,176022.msg998479.html#new" title="php coding">php coding</a><br />
on February 18, 2020, 10:03:06 PM
</p>
</td>
</tr>
<tr id="board_10" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,10.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,10.0.html" name="b10">BSD, Linux, and Unix</a>
<p>BSD, Linux, Unix, Ubuntu, and other variants discussions and help. </p>
</td>
<td class="stats windowbg">
<p>9638 Posts <br />
1520 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191044">leftwing</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,169669.msg998467.html#new" title="Re: Linux Mint 19 Cinnamon 32-bit  -- Very Good Performance for old Netbook">Re: Linux Mint 19 Cinnam...</a><br />
on February 18, 2020, 08:10:35 AM
</p>
</td>
</tr>
<tr id="board_8" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,8.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,8.0.html" name="b8">Apple</a>
<p>Apple Macintosh, Apple OS, iPad, iPhone, iPod, and other related discussions and help.</p>
</td>
<td class="stats windowbg">
<p>4916 Posts <br />
778 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=39337">BC_Programmer</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175911.msg998238.html#new" title="Re: Fake News. Apple MAC with AMD CPU.">Re: Fake News. Apple MAC...</a><br />
on February 10, 2020, 02:10:39 PM
</p>
</td>
</tr>
</tbody>
<tbody class="divider">
<tr>
<td colspan="4"></td>
</tr>
</tbody>
<tbody class="header" id="category_5">
<tr>
<td colspan="4">
<div class="cat_bar">
<h3 class="catbg">
<a id="c5"></a>Internet &amp; Networking
</h3>
</div>
</td>
</tr>
</tbody>
<tbody class="content" id="category_5_boards">
<tr id="board_12" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,12.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,12.0.html" name="b12">Networking</a>
<p>Home networks, broadband, certifications, Wi-Fi, and related help.</p>
</td>
<td class="stats windowbg">
<p>35786 Posts <br />
5001 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=190725">alvin</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175746.msg997752.html#new" title="No Network ">No Network </a><br />
on January 31, 2020, 10:47:31 AM
</p>
</td>
</tr>
<tr id="board_13" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,13.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,13.0.html" name="b13">Web design</a>
<p>HTML, CSS, Perl, PHP, XML, design, hosting, and related discussions and help.</p>
<p class="moderators">Moderator: <a href="https://www.computerhope.com/forum/index.php?action=profile;u=33929" title="Board Moderator">kpac</a></p>
</td>
<td class="stats windowbg">
<p>16220 Posts <br />
2329 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=54386">Geek-9pm</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175684.msg997538.html#new" title="Re: Web Design Responsive ">Re: Web Design Responsiv...</a><br />
on January 29, 2020, 02:09:02 PM
</p>
</td>
</tr>
</tbody>
<tbody class="divider">
<tr>
<td colspan="4"></td>
</tr>
</tbody>
<tbody class="header" id="category_2">
<tr>
<td colspan="4">
<div class="cat_bar">
<h3 class="catbg">
<a id="c2"></a>Other
 </h3>
</div>
</td>
</tr>
</tbody>
<tbody class="content" id="category_2_boards">
<tr id="board_16" class="windowbg2">
<td class="icon windowbg" rowspan="2">
<a href="https://www.computerhope.com/forum/index.php/board,16.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,16.0.html" name="b16">Other</a>
<p>Discussions, help with everything else, and general chat.</p>
</td>
<td class="stats windowbg">
<p>137980 Posts <br />
12978 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=3421">patio</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,176007.msg998476.html#new" title="Re: Will Microsoft Open-Source Windows 7?">Re: Will Microsoft Open-...</a><br />
on February 18, 2020, 05:00:07 PM
</p>
</td>
</tr>
<tr id="board_16_children">
<td colspan="3" class="children windowbg">
<strong>Child Boards</strong>: <a href="https://www.computerhope.com/forum/index.php/board,32.0.html" title="No New Posts (Topics: 2607, Posts: 47874)">Off topic</a>
</td>
</tr>
<tr id="board_17" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,17.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,17.0.html" name="b17">Computer News</a>
<p>Latest computer news and events discussions.</p>
</td>
<td class="stats windowbg">
<p>19960 Posts <br />
2664 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=190975">Balaji k</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175967.msg998340.html#new" title="Welcome ">Welcome </a><br />
on February 13, 2020, 10:00:00 PM
</p>
</td>
</tr>
<tr id="board_40" class="windowbg2">
<td class="icon windowbg">
<a href="https://www.computerhope.com/forum/index.php/board,40.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,40.0.html" name="b40">Reviews and recommendations</a>
<p>Talk about and review computer products and/or services.</p>
</td>
<td class="stats windowbg">
<p>6313 Posts <br />
780 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by lloydwu<br />
in <a href="https://www.computerhope.com/forum/index.php/topic,163587.msg996782.html#new" title="Re: VPN recommendations needed">Re: VPN recommendations ...</a><br />
on January 03, 2020, 01:29:58 PM
</p>
</td>
</tr>
<tr id="board_43" class="windowbg2">
<td class="icon windowbg" rowspan="2">
<a href="https://www.computerhope.com/forum/index.php/board,43.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,43.0.html" name="b43">Computer Hope groups</a>
<p>Meeting grounds for Computer Hope groups to get together.</p>
</td>
<td class="stats windowbg">
<p>7312 Posts <br />
474 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=72918">Allan</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,175348.msg996774.html#new" title="Re: Hi lostcoast said he banned my network provider what doe's this mean">Re: Hi lostcoast said he...</a><br />
on January 03, 2020, 05:34:25 AM
</p>
</td>
</tr>
<tr id="board_43_children">
<td colspan="3" class="children windowbg">
<strong>Child Boards</strong>: <a href="https://www.computerhope.com/forum/index.php/board,42.0.html" title="No New Posts (Topics: 137, Posts: 2430)"><span class="__cf_email__" data-cfemail="52143d3e363b3c35121a3d3f37">[email&#160;protected]</span> (Team: 67290)</a>, <a href="https://www.computerhope.com/forum/index.php/board,44.0.html" title="No New Posts (Topics: 152, Posts: 2346)">Self Built Computer Club</a>, <a href="https://www.computerhope.com/forum/index.php/board,45.0.html" title="No New Posts (Topics: 159, Posts: 2037)">Chat</a>, <a href="https://www.computerhope.com/forum/index.php/board,54.0.html" title="No New Posts (Topics: 19, Posts: 393)">WhatPulse team</a>
</td>
</tr>
<tr id="board_18" class="windowbg2">
<td class="icon windowbg" rowspan="2">
<a href="https://www.computerhope.com/forum/index.php/board,18.0.html">
<img src="https://www.computerhope.com/forum/Themes/default/images/off.png" alt="No New Posts" title="No New Posts" />
</a>
</td>
<td class="info">
<a class="subject" href="https://www.computerhope.com/forum/index.php/board,18.0.html" name="b18">FAQ solutions database</a>
<p>Forum members most commonly asked computer related questions and topics.</p>
</td>
<td class="stats windowbg">
<p>335 Posts <br />
76 Topics
</p>
</td>
<td class="lastpost">
<p><strong>Last post</strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=170778">kovacsa</a><br />
in <a href="https://www.computerhope.com/forum/index.php/topic,78644.msg990351.html#new" title="Re: What to do while waiting for a reply to question">Re: What to do while wai...</a><br />
on April 17, 2019, 02:50:26 AM
</p>
</td>
</tr>
<tr id="board_18_children">
<td colspan="3" class="children windowbg">
<strong>Child Boards</strong>: <a href="https://www.computerhope.com/forum/index.php/board,28.0.html" title="No New Posts (Topics: 12, Posts: 65)">Forum</a>, <a href="https://www.computerhope.com/forum/index.php/board,24.0.html" title="No New Posts (Topics: 20, Posts: 50)">Hardware</a>, <a href="https://www.computerhope.com/forum/index.php/board,23.0.html" title="No New Posts (Topics: 0, Posts: 0)">Internet &amp; Network</a>, <a href="https://www.computerhope.com/forum/index.php/board,26.0.html" title="No New Posts (Topics: 18, Posts: 91)">Security</a>, <a href="https://www.computerhope.com/forum/index.php/board,25.0.html" title="No New Posts (Topics: 19, Posts: 41)">Software</a>, <a href="https://www.computerhope.com/forum/index.php/board,31.0.html" title="No New Posts (Topics: 4, Posts: 77)">Other</a>, <a href="https://www.computerhope.com/forum/index.php/board,38.0.html" title="No New Posts (Topics: 1, Posts: 1)">Post new FAQ</a>, <a href="https://www.computerhope.com/forum/index.php/board,58.0.html" title="No New Posts (Topics: 2, Posts: 10)">FAQ Archive</a>
</td>
</tr>
</tbody>
<tbody class="divider">
<tr>
<td colspan="4"></td>
</tr>
</tbody>
</table>
</div>
<div id="posting_icons" class="flow_hidden">
<ul class="reset">
<li class="floatleft"><img src="https://www.computerhope.com/forum/Themes/default/images/new_none.png" alt="" /> No New Posts</li>
<li class="floatleft"><img src="https://www.computerhope.com/forum/Themes/default/images/new_redirect.png" alt="" /> Redirect Board</li>
</ul>
</div>
<span class="clear upperframe"><span></span></span>
<div class="roundframe"><div class="innerframe">
<div class="cat_bar">
<h3 class="catbg">
<img class="icon" id="upshrink_ic" src="https://www.computerhope.com/forum/Themes/default/images/collapse.gif" alt="*" title="Shrink or expand the header." style="display: none;" />
Computer Hope - Info Center
</h3>
</div>
<div id="upshrinkHeaderIC">
<div class="title_barIC">
<h4 class="titlebg">
<span class="ie6_header floatleft">
<a href="https://www.computerhope.com/forum/index.php?action=recent"><img class="icon" src="https://www.computerhope.com/forum/Themes/default/images/post/xx.gif" alt="Recent Posts" /></a>
Recent Posts
</span>
</h4>
</div>
<div class="hslice" id="recent_posts_content">
<div class="entry-title" style="display: none;">Computer Hope - Recent Posts</div>
<div class="entry-content" style="display: none;">
<a rel="feedurl" href="https://www.computerhope.com/forum/index.php?action=.xml;type=webslice">Subscribe to Webslice</a>
</div>
<dl id="ic_recentposts" class="middletext">
<dt><strong><a href="https://www.computerhope.com/forum/index.php/topic,176031.msg998492/topicseen.html#msg998492" rel="nofollow">Topic: Need help for ransomware virus </a></strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191074">hearthot2545</a> (<a href="https://www.computerhope.com/forum/index.php/board,7.0.html">Computer viruses and spyware</a>)</dt>
<dd><strong>Today</strong> at 07:35:43 AM</dd>
<dt><strong><a href="https://www.computerhope.com/forum/index.php/topic,176023.msg998491/topicseen.html#msg998491" rel="nofollow">Re: win 7 to win 10</a></strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=140339">strollin</a> (<a href="https://www.computerhope.com/forum/index.php/board,59.0.html">Windows 10</a>)</dt>
<dd><strong>Today</strong> at 07:27:32 AM</dd>
<dt><strong><a href="https://www.computerhope.com/forum/index.php/topic,176023.msg998490/topicseen.html#msg998490" rel="nofollow">Re: win 7 to win 10</a></strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191068">Pejorative</a> (<a href="https://www.computerhope.com/forum/index.php/board,59.0.html">Windows 10</a>)</dt>
<dd><strong>Today</strong> at 06:29:30 AM</dd>
<dt><strong><a href="https://www.computerhope.com/forum/index.php/topic,176030.msg998489/topicseen.html#msg998489" rel="nofollow">MOVED: win 7 to win 10</a></strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=72918">Allan</a> (<a href="https://www.computerhope.com/forum/index.php/board,5.0.html">Hardware</a>)</dt>
<dd><strong>Today</strong> at 05:28:28 AM</dd>
<dt><strong><a href="https://www.computerhope.com/forum/index.php/topic,176023.msg998488/topicseen.html#msg998488" rel="nofollow">Re: win 7 to win 10</a></strong> by <a href="https://www.computerhope.com/forum/index.php?action=profile;u=72918">Allan</a> (<a href="https://www.computerhope.com/forum/index.php/board,59.0.html">Windows 10</a>)</dt>
<dd><strong>Today</strong> at 05:28:15 AM</dd>
</dl>
</div>
<div class="title_barIC">
<h4 class="titlebg">
<span class="ie6_header floatleft">
<a href="https://www.computerhope.com/forum/index.php?action=stats"><img class="icon" src="https://www.computerhope.com/forum/Themes/default/images/icons/info.gif" alt="Forum Stats" /></a>
Forum Stats
</span>
</h4>
</div>
<p>
1177096 Posts in 134563 Topics by 34424 Members. Latest Member: <strong> <a href="https://www.computerhope.com/forum/index.php?action=profile;u=191081">bridg</a></strong><br />
Latest Post: <strong>&quot;<a href="https://www.computerhope.com/forum/index.php/topic,176031.msg998492.html#new" title="Topic: Need help for ransomware virus  ">Topic: Need help for ran...</a>&quot;</strong> ( <strong>Today</strong> at 07:35:43 AM )<br />
<a href="https://www.computerhope.com/forum/index.php?action=recent">View the most recent posts on the forum.</a>
</p>
<div class="title_barIC">
<h4 class="titlebg">
<span class="ie6_header floatleft">
<img class="icon" src="https://www.computerhope.com/forum/Themes/default/images/icons/online.gif" alt="Users Online" />
Users Online
</span>
</h4>
</div>
<p class="inline stats">
353 Guests, 1 User
</p>
<p class="inline smalltext">
Users active in past 30 minutes:<br /><a href="https://www.computerhope.com/forum/index.php?action=profile;u=191081" style="color: #808080;">bridg</a>
</p>
<p class="last smalltext">
Most Online Today: <strong>507</strong>.
Most Online Ever: 4845 (March 31, 2017, 04:06:57 AM)
</p>
</div>
</div></div>
<span class="lowerframe"><span></span></span>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript"><!-- // --><![CDATA[
		var oInfoCenterToggle = new smc_Toggle({
			bToggleEnabled: true,
			bCurrentlyCollapsed: false,
			aSwappableContainers: [
				'upshrinkHeaderIC'
			],
			aSwapImages: [
				{
					sId: 'upshrink_ic',
					srcExpanded: smf_images_url + '/collapse.gif',
					altExpanded: 'Shrink or expand the header.',
					srcCollapsed: smf_images_url + '/expand.gif',
					altCollapsed: 'Shrink or expand the header.'
				}
			],
			oThemeOptions: {
				bUseThemeSettings: false,
				sOptionName: 'collapse_header_ic',
				sSessionVar: 'a4ba615fb8',
				sSessionId: 'abce47b1dc4e8e634b69963461bd3365'
			},
			oCookieOptions: {
				bUseCookie: true,
				sCookieName: 'upshrinkIC'
			}
		});
	// ]]></script>
</div>
</div></div>
<br /><div id="footer_section"><div class="frame"><a href="https://www.computerhope.com/forum/index.php?action=search">Old Forum Search</a> | <a href="https://www.computerhope.com/forum/index.php/topic,58736.0.html">Forum Rules</a><br />
<a href="https://www.computerhope.com/legal.htm">Copyright &copy; 2017 Computer Hope &reg; All rights reserved.</a><br />
<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="https://www.computerhope.com/forum/index.php?action=credits" title="Simple Machines Forum" target="_blank" class="new_win">SMF 2.0.15</a> |
<a href="https://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2017</a>, <a href="https://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a>
</span>
<p>Page created in 0.198 seconds with 8 queries.</p>
</div></div>
</div>
</body></html>